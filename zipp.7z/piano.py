import sys

from PyQt5 import uic, QtCore, QtMultimedia  # Импортируем uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('piano.ui', self)  # Загружаем дизайн
        self.label.setPixmap(QPixmap("inf3.jpeg"))
        self.doo.clicked.connect(self.run_do)
        self.re.clicked.connect(self.run_re)
        self.mi.clicked.connect(self.run_mi)
        self.fa.clicked.connect(self.run_fa)
        self.sol.clicked.connect(self.run_sol)
        self.la.clicked.connect(self.run_la)
        self.si.clicked.connect(self.run_si)
        self.do1.clicked.connect(self.run_do1)
        self.re1.clicked.connect(self.run_re1)
        self.mi1.clicked.connect(self.run_mi1)
        self.do_s.clicked.connect(self.run_do_s)
        self.re_s.clicked.connect(self.run_re_s)
        self.fa_s.clicked.connect(self.run_fa_s)
        self.sol_s.clicked.connect(self.run_sol_s)
        self.la_s.clicked.connect(self.run_la_s)
        self.do1_s.clicked.connect(self.run_do1_s)
        self.re1_s.clicked.connect(self.run_re1_s)
        # self.pushButton.clicked.connect(self.run)
        # Обратите внимание: имя элемента такое же как в QTDesigner

    def run_do(self):
        self.music('do.mp3')

    def run_re(self):
        self.music('re.mp3')

    def run_mi(self):
        self.music('mi.mp3')

    def run_fa(self):
        self.music('fa.mp3')

    def run_sol(self):
        self.music('sol.mp3')

    def run_la(self):
        self.music('la.mp3')

    def run_si(self):
        self.music('si.mp3')

    def run_do1(self):
        self.music('do1.mp3')

    def run_re1(self):
        self.music('re1.mp3')

    def run_mi1(self):
        self.music('mi1.mp3')

    def run_do_s(self):
        self.music('do_s.mp3')

    def run_re_s(self):
        self.music('re_s.mp3')

    def run_fa_s(self):
        self.music('fa_s.mp3')

    def run_sol_s(self):
        self.music('sol_s.mp3')

    def run_la_s(self):
        self.music('la_s.mp3')

    def run_do1_s(self):
        self.music('do1_s.mp3')

    def run_re1_s(self):
        self.music('re1_s.mp3')

    def music(self, name):
        self.fullpath = QtCore.QDir.current().absoluteFilePath(name)
        self.url = QtCore.QUrl.fromLocalFile(self.fullpath)
        self.content = QtMultimedia.QMediaContent(self.url)
        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(self.content)
        self.player.setVolume(50)
        self.player.play()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Z:
            self.music('do.mp3')
        elif event.key() == Qt.Key_X: self.music('re.mp3')
        elif event.key() == Qt.Key_C: self.music('mi.mp3')
        elif event.key() == Qt.Key_V: self.music('fa.mp3')
        elif event.key() == Qt.Key_B: self.music('sol.mp3')
        elif event.key() == Qt.Key_N: self.music('la.mp3')
        elif event.key() == Qt.Key_M: self.music('si.mp3')
        elif event.key() == Qt.Key_Comma: self.music('do1.mp3')
        elif event.key() == Qt.Key_Period: self.music('re1.mp3')
        elif event.key() == Qt.Key_Slash: self.music('mi1.mp3')
        elif event.key() == Qt.Key_S: self.music('do_s.mp3')
        elif event.key() == Qt.Key_D: self.music('re_s.mp3')
        elif event.key() == Qt.Key_G: self.music('fa_s.mp3')
        elif event.key() == Qt.Key_H: self.music('sol_s.mp3')
        elif event.key() == Qt.Key_J: self.music('la_s.mp3')
        elif event.key() == Qt.Key_L: self.music('do1_s.mp3')
        elif event.key() == Qt.Key_Semicolon: self.music('re1_s.mp3')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
